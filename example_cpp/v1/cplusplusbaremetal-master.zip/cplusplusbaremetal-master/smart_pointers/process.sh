pandoc $1 -o file.html
chromium-browser file.html &
