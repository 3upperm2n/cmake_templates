#ifndef FIZZBUZZ
#define FIZZBUZZ
#include <string>

std::string fizzbuzz(int value);

#endif
