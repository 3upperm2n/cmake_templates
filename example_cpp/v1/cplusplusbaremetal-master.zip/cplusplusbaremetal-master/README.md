cplusplusbaremetal
==================

Code used in the blog http://cplusplusbaremetal.blogspot.com
