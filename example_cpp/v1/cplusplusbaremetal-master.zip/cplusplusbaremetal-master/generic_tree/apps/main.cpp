#include <iostream>
#include <string>
#include <limits>
#include <Tree.ipp>

int main(int argc, char** argv) {
  tree::Tree<int> t;
  t.add(3);
}
